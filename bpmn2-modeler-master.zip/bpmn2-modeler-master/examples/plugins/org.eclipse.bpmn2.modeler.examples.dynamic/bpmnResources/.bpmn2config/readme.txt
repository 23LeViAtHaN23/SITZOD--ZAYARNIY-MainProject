This folder contains examples of how to define extension point features for the BPMN2 Modeler.

All files in this folder will be loaded by the BPMN2 Builder whenever a file changes,
and will be applied to open editors. Note that the BPMN2 Nature must be added to the
Eclipse ".project" file. To add the BPMN2 Nature, open the project Properties dialog
(right-click on a project and select "Properties" from the context menu) then enable
the "Check if project is configured for BPMN2 Project Nature" toggle. The next time
the editor is saved, it will prompt to add the project nature. 